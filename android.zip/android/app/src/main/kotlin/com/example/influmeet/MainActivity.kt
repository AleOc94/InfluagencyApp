package com.example.influmeet

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
